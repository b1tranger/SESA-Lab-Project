initial idea [https://nevonprojects.com/price-comparison-website-for-online-shopping-project/](https://nevonprojects.com/price-comparison-website-for-online-shopping-project/)



updated idea: ecommerce website to deliver products within 10 minutes.



delivery can be done using drone?



- when the customer places orders, the orders will be redirected to the nearest supplier, and afterwards the deliveryman will deliver the product as soon as possible. 
- So as a groundwork, we must build strong connection with the suppliers, either through networking or contracts. 
- There can be several suppliers, and the first one to respond will get the order - this should create an incentive to work actively among the suppliers.

